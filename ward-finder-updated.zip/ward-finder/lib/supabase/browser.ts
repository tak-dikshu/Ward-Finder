'use client'
import { createBrowserClient } from '@supabase/ssr'

// Browser client uses only the public URL and anon/publishable key.
export function createBrowserSupabase() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY
  if (!url || !key) throw new Error('Supabase is not configured.')
  return createBrowserClient(url, key)
}
